import rclpy
from rclpy.node import Node
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
import time


class PathPublisher(Node):
    def __init__(self):
        super().__init__('manual_path_publisher')
        self.publisher = self.create_publisher(Path, '/path_data', 10)
        timer_period = 2.0  # publish once after a delay
        self.timer = self.create_timer(timer_period, self.publish_path)

    def publish_path(self):
        path_msg = Path()
        path_msg.header.frame_id = "map"  # or "base_link", depending on your system
        path_msg.header.stamp = self.get_clock().now().to_msg()

        # Define custom waypoints (x, y coordinates)
        waypoints = [
            (3, 6.5),
            (3.5, 6.5),
            (3.5, 5.8),
            (3.5, 5.0),
            (3.5, 4.8),
            (3.5, 4.5),
            (3.5, 4.2),
            (3.5, 4.0),
            (3.5, 3.9),
            (3.5, 3.7),
            (3.5, 3.5),
            (3.5, 3.2),
            (3.5, 3.0),
            (3.5, 2.8),
            (3.5, 2.5),
            (3.5, 2.3),
            (3.5, 1.0),
            (3.0, 0.5),
            (2.5, 0.5),
            (2.2, 0.5),
            (2.0, 0.5),
            (1.8, 0.5),
            (1.5, 0.5),
            (1.4, 0.5),
            (1.2, 0.5),
            (1.0, 0.5),
            (0.5, 1.0),
            (0.5, 1.2),
            (0.5, 1.5),
            (0.5, 2.0),
            (0.5, 2.2),
            (0.5, 3.0),
            (0.5, 3.4),
            (0.5, 4.0),
            (0.5, 4.2),
            (0.5, 4.7),
            (0.5, 5.0),
            (0.5, 5.5),
            (0.5, 5.8),
            (0.5, 6.0),
            (0.5, 6.4),
            (0.5, 6.8),
            (0.5, 7.0)
        ]

        for i, (x, y) in enumerate(waypoints):
            pose = PoseStamped()
            pose.header.frame_id = "map"
            pose.header.stamp = self.get_clock().now().to_msg()
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = 0.0
            pose.pose.orientation.w = 1.0  # facing forward
            path_msg.poses.append(pose)

        self.publisher.publish(path_msg)
        self.get_logger().info("Published custom path with {} waypoints.".format(len(waypoints)))
        self.destroy_timer(self.timer)  # Only publish once


def main(args=None):
    rclpy.init(args=args)
    node = PathPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
